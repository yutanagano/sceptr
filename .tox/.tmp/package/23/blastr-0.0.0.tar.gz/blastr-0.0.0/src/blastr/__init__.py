"""
package root
"""


from .default_functions import embed, cdist, pdist
